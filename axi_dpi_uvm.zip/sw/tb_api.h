#include <stdint.h>

void write32(uint32_t addr, uint32_t data);
uint32_t read32(uint32_t addr);