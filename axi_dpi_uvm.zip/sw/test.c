#include "tb_api.h"

int main() {
    write32(0x10, 0x1234);
    write32(0x14, 0x5678);

    uint32_t a = read32(0x10);
    uint32_t b = read32(0x14);

    return 0;
}