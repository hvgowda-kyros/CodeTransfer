#include "tb_api.h"

extern void sv_write32(unsigned int addr, unsigned int data);
extern unsigned int sv_read32(unsigned int addr);

void write32(uint32_t addr, uint32_t data) {
    sv_write32(addr, data);
}

uint32_t read32(uint32_t addr) {
    return sv_read32(addr);
}