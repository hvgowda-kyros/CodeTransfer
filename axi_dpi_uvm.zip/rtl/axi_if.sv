interface axi_if #(parameter ADDR_W=32, DATA_W=32) (input clk, reset_n);

  logic [ADDR_W-1:0] awaddr;
  logic awvalid, awready;

  logic [DATA_W-1:0] wdata;
  logic wvalid, wready;

  logic bvalid, bready;

  logic [ADDR_W-1:0] araddr;
  logic arvalid, arready;

  logic [DATA_W-1:0] rdata;
  logic rvalid, rready;

endinterface