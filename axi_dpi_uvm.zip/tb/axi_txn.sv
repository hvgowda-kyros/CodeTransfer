class axi_txn extends uvm_sequence_item;
  rand bit [31:0] addr;
  rand bit [31:0] data;
  rand bit write;

  constraint align { addr[1:0] == 0; }

  `uvm_object_utils(axi_txn)

  function new(string name="axi_txn");
    super.new(name);
  endfunction
endclass