class axi_slave extends uvm_component;

  virtual axi_if vif;
  bit [31:0] mem [0:1023];

  `uvm_component_utils(axi_slave)

  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.clk);

      if (vif.awvalid) begin
        vif.awready <= 1;
      end else vif.awready <= 0;

      if (vif.wvalid) begin
        vif.wready <= 1;
        mem[vif.awaddr] = vif.wdata;
        vif.bvalid <= 1;
      end else begin
        vif.wready <= 0;
        vif.bvalid <= 0;
      end

      if (vif.arvalid) begin
        vif.arready <= 1;
        vif.rdata <= mem[vif.araddr];
        vif.rvalid <= 1;
      end else begin
        vif.arready <= 0;
      end

      if (vif.rvalid && vif.rready)
        vif.rvalid <= 0;
    end
  endtask
endclass