module tb_top;

  import uvm_pkg::*;
  import dpi_bridge_pkg::*;

  bit clk=0;
  always #5 clk = ~clk;

  bit reset_n;
  initial begin
    reset_n = 0;
    #20 reset_n = 1;
  end

  axi_if vif(clk, reset_n);

  initial begin
    req_mb = new();
    rsp_mb = new();
  end

  import "DPI-C" function int main();

  initial begin
    wait(reset_n);
    #10;
    main();
    #1000 $finish;
  end

endmodule