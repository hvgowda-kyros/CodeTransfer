package dpi_bridge_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef class axi_txn;

  mailbox #(axi_txn) req_mb;
  mailbox #(axi_txn) rsp_mb;

endpackage