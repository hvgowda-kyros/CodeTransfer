interface jtag_if(input logic tck);
  logic tms;
  logic tdi;
  logic tdo;
endinterface
