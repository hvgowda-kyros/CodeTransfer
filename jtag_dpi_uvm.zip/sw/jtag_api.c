#include "jtag_api.h"

extern uint64_t sv_jtag_ir_scan(uint64_t data, int nbits);
extern uint64_t sv_jtag_dr_scan(uint64_t data, int nbits);

uint64_t jtag_ir_scan(uint64_t data, int nbits) {
    return sv_jtag_ir_scan(data, nbits);
}

uint64_t jtag_dr_scan(uint64_t data, int nbits) {
    return sv_jtag_dr_scan(data, nbits);
}
