#include <stdint.h>

uint64_t jtag_ir_scan(uint64_t data, int nbits);
uint64_t jtag_dr_scan(uint64_t data, int nbits);
