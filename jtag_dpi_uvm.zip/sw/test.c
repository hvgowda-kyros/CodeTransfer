#include "jtag_api.h"

int main() {
    uint64_t ir = jtag_ir_scan(0x1F, 5);
    uint64_t dr = jtag_dr_scan(0xA5A5, 16);
    return 0;
}
