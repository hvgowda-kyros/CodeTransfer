class jtag_slave extends uvm_component;

  virtual jtag_if vif;
  bit [63:0] shift_reg;

  `uvm_component_utils(jtag_slave)

  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.tck);
      shift_reg = {vif.tdi, shift_reg[63:1]};
      vif.tdo <= shift_reg[0];
    end
  endtask
endclass
