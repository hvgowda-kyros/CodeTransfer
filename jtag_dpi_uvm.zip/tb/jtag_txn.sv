class jtag_txn extends uvm_sequence_item;
  rand bit [63:0] data;
  rand int nbits;
  rand bit is_ir;

  `uvm_object_utils(jtag_txn)

  function new(string name="jtag_txn");
    super.new(name);
  endfunction
endclass
