class jtag_driver extends uvm_component;

  virtual jtag_if vif;
  import dpi_jtag_pkg::*;

  `uvm_component_utils(jtag_driver)

  task drive_tms(bit val);
    @(posedge vif.tck);
    vif.tms <= val;
  endtask

  task goto_shift_ir();
    drive_tms(1);
    drive_tms(1);
    drive_tms(0);
    drive_tms(0);
  endtask

  task goto_shift_dr();
    drive_tms(1);
    drive_tms(0);
    drive_tms(0);
  endtask

  task shift_bits(bit [63:0] data, int nbits, output bit [63:0] rdata);
    for (int i=0;i<nbits;i++) begin
      @(posedge vif.tck);
      vif.tdi <= data[i];
      rdata[i] = vif.tdo;
    end
  endtask

  task run_phase(uvm_phase phase);
    jtag_txn tx;
    bit [63:0] rdata;

    forever begin
      req_mb.get(tx);

      if (tx.is_ir)
        goto_shift_ir();
      else
        goto_shift_dr();

      shift_bits(tx.data, tx.nbits, rdata);
      tx.data = rdata;

      rsp_mb.put(tx);
    end
  endtask
endclass
