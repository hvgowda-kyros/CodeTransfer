module tb_top;

  import uvm_pkg::*;
  import dpi_jtag_pkg::*;

  bit tck=0;
  always #5 tck = ~tck;

  jtag_if jif(tck);

  initial begin
    req_mb = new();
    rsp_mb = new();
  end

  import "DPI-C" function int main();

  initial begin
    #20;
    main();
    #1000 $finish;
  end

endmodule
