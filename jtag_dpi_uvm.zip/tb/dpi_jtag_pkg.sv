package dpi_jtag_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef class jtag_txn;

  mailbox #(jtag_txn) req_mb;
  mailbox #(jtag_txn) rsp_mb;
endpackage
