import dpi_jtag_pkg::*;

export "DPI-C" function sv_jtag_ir_scan;
export "DPI-C" function sv_jtag_dr_scan;

function longint sv_jtag_ir_scan(longint data, int nbits);
  jtag_txn tx = new();
  jtag_txn rsp;

  tx.data = data;
  tx.nbits = nbits;
  tx.is_ir = 1;

  req_mb.put(tx);
  rsp_mb.get(rsp);

  return rsp.data;
endfunction

function longint sv_jtag_dr_scan(longint data, int nbits);
  jtag_txn tx = new();
  jtag_txn rsp;

  tx.data = data;
  tx.nbits = nbits;
  tx.is_ir = 0;

  req_mb.put(tx);
  rsp_mb.get(rsp);

  return rsp.data;
endfunction
