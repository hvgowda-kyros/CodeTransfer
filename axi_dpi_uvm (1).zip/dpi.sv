import dpi_bridge_pkg::*;

export "DPI-C" function sv_write32;
export "DPI-C" function sv_read32;
export "DPI-C" function tb_print;

function void sv_write32(int addr, int data);
  axi_txn tx=new(); tx.addr=addr; tx.data=data; tx.write=1;
  req_mb.put(tx);
endfunction

function int sv_read32(int addr);
  axi_txn tx=new(); axi_txn rsp;
  tx.addr=addr; tx.write=0;
  req_mb.put(tx);
  rsp_mb.get(rsp);
  return rsp.data;
endfunction

function void tb_print(string msg);
  $display("[C_TEST] %s", msg);
endfunction