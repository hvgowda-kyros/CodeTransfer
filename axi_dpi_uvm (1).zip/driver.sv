import dpi_bridge_pkg::*;
class axi_driver extends uvm_component;
  virtual axi_if vif;
  `uvm_component_utils(axi_driver)

  task run_phase(uvm_phase phase);
    axi_txn tx;
    forever begin
      req_mb.get(tx);
      if(tx.write) begin
        @(posedge vif.clk);
        vif.awaddr <= tx.addr; vif.awvalid <= 1;
        wait(vif.awready);
        @(posedge vif.clk); vif.awvalid <= 0;

        vif.wdata <= tx.data; vif.wvalid <= 1;
        wait(vif.wready);
        @(posedge vif.clk); vif.wvalid <= 0;

        vif.bready <= 1; wait(vif.bvalid);
        @(posedge vif.clk); vif.bready <= 0;
      end else begin
        @(posedge vif.clk);
        vif.araddr <= tx.addr; vif.arvalid <= 1;
        wait(vif.arready);
        @(posedge vif.clk); vif.arvalid <= 0;

        vif.rready <= 1; wait(vif.rvalid);
        tx.data = vif.rdata;
        @(posedge vif.clk); vif.rready <= 0;
        rsp_mb.put(tx);
      end
    end
  endtask
endclass