module tb_top;
  import uvm_pkg::*;
  import dpi_bridge_pkg::*;

  bit clk=0, reset_n=0;
  always #5 clk = ~clk;

  axi_if vif(clk, reset_n);
  axi_driver drv;

  import "DPI-C" function int main();

  initial begin
    req_mb = new();
    rsp_mb = new();
    drv = new("drv", null);
    drv.vif = vif;
    reset_n = 0;
    #20 reset_n = 1;
    fork drv.run_phase(null); join_none
    #10 main();
    #200 $finish;
  end
endmodule