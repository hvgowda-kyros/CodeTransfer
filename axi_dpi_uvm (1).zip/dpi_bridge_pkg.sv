package dpi_bridge_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  class axi_txn extends uvm_sequence_item;
    rand bit [31:0] addr, data;
    rand bit write;
    `uvm_object_utils(axi_txn)
    function new(string name="axi_txn"); super.new(name); endfunction
  endclass

  mailbox #(axi_txn) req_mb;
  mailbox #(axi_txn) rsp_mb;
endpackage