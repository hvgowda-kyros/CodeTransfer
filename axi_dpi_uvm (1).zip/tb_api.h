#ifndef TB_API_H
#define TB_API_H
#include <stdint.h>
void write32(uint32_t addr, uint32_t data);
uint32_t read32(uint32_t addr);
void tb_print(const char *msg);
#endif