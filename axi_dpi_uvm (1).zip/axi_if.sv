interface axi_if(input clk, reset_n);
  logic [31:0] awaddr; logic awvalid, awready;
  logic [31:0] wdata;  logic wvalid, wready;
  logic bvalid, bready;
  logic [31:0] araddr; logic arvalid, arready;
  logic [31:0] rdata;  logic rvalid, rready;
endinterface