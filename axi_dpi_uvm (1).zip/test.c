#include "tb_api.h"
#define BASE 0x10

int main() {
    tb_print("Starting DPI AXI test");
    write32(BASE, 0xDEADBEEF);
    write32(BASE+4, 0xCAFEBABE);
    uint32_t r1 = read32(BASE);
    uint32_t r2 = read32(BASE+4);
    return 0;
}